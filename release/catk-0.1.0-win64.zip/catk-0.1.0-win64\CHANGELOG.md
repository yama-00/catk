# Changelog

## 0.1.0 - 2025-09-07
- 初回リリース
- 機能:
  - `clean`: CSV整形（空白・重複・文字化け除去）
  - `report`: 複数CSV統合 → Excelレポート生成
  - `scrape`: Webスクレイピング → CSV蓄積
- Windows向け EXE 配布に対応
- サンプル入力（examples/）、サンプル設定（configs/）を同梱
